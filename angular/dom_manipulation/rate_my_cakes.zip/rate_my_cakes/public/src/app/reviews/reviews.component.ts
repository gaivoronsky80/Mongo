import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent implements OnInit {
  newReview: any;
  @Input() cakeId: any;

  constructor(private _httpService: HttpService) {
    this.newReview = {
      comment: "",
      rate: ""
    };
  }

  ngOnInit() {
  }

  reviewCake(){
    const obs = this._httpService.sendReviewToDB(this.cakeId, this.newReview)
    obs.subscribe(data => {
      console.log(data);
    })
  }

}
