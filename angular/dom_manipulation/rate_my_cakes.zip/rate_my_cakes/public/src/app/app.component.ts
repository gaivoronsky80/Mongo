import { Component } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'public';
  cakes: any;
  newCake: any;
  cakeSelected: any;

  constructor(private _httpService: HttpService){


    this.resetCakes();
    this.getAllCakes();
  }

  resetCakes(){
    this.newCake = {
      baker: "",
      img: ""
    }
  }

  getAllCakes(){
    const obs = this._httpService.getCakesFromDB();
    obs.subscribe(data => {
      this.cakes = data;
    });
  }

  createCake(){
    const obs = this._httpService.sendCakeToDB(this.newCake);
    obs.subscribe(data => {
        console.log("New cake", data)
        this.resetCakes();
        this.getAllCakes();
    });
  }

  showOneCake(cake){
    this.cakeSelected = cake;
    console.log(cake)
  }
}