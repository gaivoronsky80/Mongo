import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) {}

  getHomePage(){
    return this._http.get('/');
  }

  getProductsFromDB(){
    return this._http.get('/products');
  }

  sendProductToDB(editProduct){
    return this._http.post('/products/new', editProduct);
  }

  deleteProductFromDB(productId){
    return this._http.delete('/products/delete/' + productId);
  }

  editProductInDB(editProduct){
    return this._http.put('/products/edit/' + editProduct._id, editProduct);
  }
}