// import { Component, OnInit, Input } from '@angular/core';

// @Component({
//   selector: 'app-rate-my-cake',
//   templateUrl: './rate-my-cake.component.html',
//   styleUrls: ['./rate-my-cake.component.css']
// })
// export class RateMyCakeComponent implements OnInit {
//   @Input() cakeToShow: any;
//   constructor() { }

//   ngOnInit() { }

// }
