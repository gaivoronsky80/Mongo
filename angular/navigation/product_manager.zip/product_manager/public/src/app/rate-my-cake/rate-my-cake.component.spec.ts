import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RateMyCakeComponent } from './rate-my-cake.component';

describe('RateMyCakeComponent', () => {
  let component: RateMyCakeComponent;
  let fixture: ComponentFixture<RateMyCakeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RateMyCakeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RateMyCakeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
