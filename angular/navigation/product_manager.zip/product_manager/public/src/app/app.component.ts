import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'public';
  products: any;
  newProduct: any;
  editProduct: any;
  productId: any;
  showEditForm = false;
  showCreateForm = false;
  showListPage = false;
  showHomePage = true;

  constructor(private _httpService: HttpService){
    this.resetProducts();
    this.getAllProducts();
  }

  ngOnInit() {
  }

  resetProducts(){
    this.newProduct = {
      title: "",
      price: "",
      img: ""
    }
  }

  homeOnClick(){
    this.products.showHomePage = true;
  }

  listOnClick(products){
    console.log("Work!");
    products.showListPage = true;
  }

  getAllProducts(){
    const obs = this._httpService.getProductsFromDB();
    obs.subscribe(data => {
      this.products = data;
    });
  }

  createOnClick(newProduct){
    console.log("Work!");
    newProduct.showCreateForm = true;
  }

  createProduct(){
    const obs = this._httpService.sendProductToDB(this.newProduct);
    obs.subscribe(data => {
        console.log("New product", data)
        this.resetProducts();
        this.getAllProducts();
    });
  }

  updateProduct(editProduct){
    editProduct.showEditForm = false;
    const obs = this._httpService.editProductInDB(editProduct)
    obs.subscribe(data => {
      console.log(data);
      this.editProduct = {title:"", price:"", img:""};
      this.getAllProducts();
    });
  }

  editOnClick(editProduct){
    console.log("Work!", editProduct);
    editProduct.showEditForm = true;
    this.newProduct.showCreateForm = false;
    this.products.showListPage = false;
  }

  deleteProduct(productId){
    const obs = this._httpService.deleteProductFromDB(productId)
    obs.subscribe(data => {
      console.log(data);
      this.getAllProducts();
    });
  }

  onCancel(){
    this.getAllProducts();
  }
}