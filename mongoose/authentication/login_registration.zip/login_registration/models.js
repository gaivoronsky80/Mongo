    const mongoose = require('mongoose');
    mongoose.connect('mongodb://localhost/login_registration');

    var first_nameValidator = first_name => {
      if(first_name.length < 0) {return false}
      return true;
    }

    var last_nameValidator = last_name => {
      if(last_name.length < 0) {return false}
      return true;
    }

    var emailValidator = email => {
      var EMAIL_REGEX = '^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$';
      if(email.match (EMAIL_REGEX)) {return true}
      return false;
    }

    var birthdayValidator = birthday => {
      if(birthday == None) {return true}
      return false;
    }
    
    const UserSchema = new mongoose.Schema({
      first_name: {type: String, required: [true, 'A first name is required'], validate : first_nameValidator},
      last_name: {type: String, required: [true, 'A last name is required'], validate : last_nameValidator},
      email: {type: String, required: [true, 'An email is required'], validate : emailValidator},
      password: {type: String, required: [true, 'A password is required']},
      birthday: {type: Date, required: [true, 'A birthday is required'], validate : birthdayValidator},
      created_at: { type: Date, default: Date.now}
    }, {timestamps: true})

    mongoose.model('User', UserSchema); // We are setting this Schema in our Models as 'User'
    const User = mongoose.model('User');

    module.exports = User;