const User = require("./models");
const bcrypt = require ('bcrypt');

module.exports = {
    index: function(req, res){
        if ('user_id' in req.session ){ 
            res.redirect ('/dashboard')
        }
        else { 
            res.render ('index') 
        } 
    },

    registration: function(req,res){
        var pw_hash;
        bcrypt.hash(req.body.password, 10)
        .then (hashed_password => {
            pw_hash = hashed_password;
            User.create({first_name: req.body.first_name, last_name: req.body.last_name, email: req.body.email, pw_hash: pw_hash, birthday: req.body.birthday})
            .then (result => {
                req.session.user_id = result._id;
                res.redirect('/dashboard');
            })
            .catch (err => {
                res.redirect('/');
            })
        })
        .catch(err => {
            res.redirect('/');
        })
    },

    login: function(req,res){
        User.find({email: req.body.email})
        .then(user => {
            bcrypt.compare(req.body.password, user.pw_hash)
            .then(result => {
                req.session.user_id = user._id;
                res.redirect('/dashboard');
            })
            .catch(err => {
                res.redirect('/');
            })
        })
        .catch(err => {
            res.redirect('/');
        })
    },

    dashboard: function(req,res){
        if('user_id' in req.session){
            res.render('dashboard', {data:req.session});
        }
        else{
            res.redirect('/');
        }
    },

    logout: function(req,res){
        req.session.destroy();
        res.redirect('/');
    }
}   




